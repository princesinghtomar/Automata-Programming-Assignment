# Automata-Programming-Assignment
> Name : Prince Singh Tomar

> Roll Number : 2019101021
## Question 1 :
> Regex to NFA Conversion
- Converted given Regex to infix form
- Converted the infix to postfix form
- Make NFA for base case
- From this make continue making NFA for other Regex characters.
- Continued making NFA as per the rules
- After ending of the Regex string required NFA was present in the stack

## Question 2 :
> NFA to DFA Conversion
- Get Combination of all States that can be present in DFA
- Mark Start State
- Update transition matrix

## Question 3 :
> DFA to Regex Conversion
- Convert DFA to GNFA
- Update transition matrix
- Do State Reduction
- When only 2 States are left STOP
- Got required Regex

# Question 4 :
> Minimize DFA
- Method used Myhill-Nerode theorem
- Remove all unreachable and dead States
- Divide States in 2 parts one which are not Final and Final States
- Follow the Theorem
- Got the minimized DFA

Video Link : https://iiitaphyd-my.sharepoint.com/:v:/g/personal/prince_tomar_students_iiit_ac_in/EbkBsvCVo9BHpzp28Ms4VpgB9kZlk_ZdYR-lBZ3zBsBynw?e=VGSXbv